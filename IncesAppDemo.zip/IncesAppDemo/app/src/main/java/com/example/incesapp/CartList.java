package com.example.incesapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.incesapp.DatabaseHelper.Database;
import com.example.incesapp.helper.PreferenceHelper;
import com.example.incesapp.helper.SharedPrefHelper;
import com.example.incesapp.models.ProductModel;
import com.example.incesapp.models.UserModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

public class CartList extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.reccart)
    RecyclerView reccart;

    Database db;
    ArrayList<ProductModel> pmlist = new ArrayList();
    ShopAdapter shpadapt;
    public static SharedPreferences sp;
    public static SharedPrefHelper dataProcessor;
    @BindView(R.id.nodata)
    LinearLayout nodata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_list);
        ButterKnife.bind(this);
        sp = getSharedPreferences("medical_prefs", MODE_PRIVATE);
        dataProcessor = new SharedPrefHelper(this);
        toolbar.setTitle("My Cart");
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        db = new Database(this);
        pmlist.addAll(getShoppingProduct(this));

        GridLayoutManager llm = new GridLayoutManager(this, 2);
        llm.setOrientation(RecyclerView.VERTICAL);
        reccart.setLayoutManager(llm);
        reccart.setHasFixedSize(true);
        reccart.setNestedScrollingEnabled(false);
        shpadapt = new ShopAdapter(pmlist, this);
        reccart.setAdapter(shpadapt);

         if(pmlist.size()==0){
             nodata.setVisibility(View.VISIBLE);
         }else{
             nodata.setVisibility(View.GONE);
         }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater();
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return false;
        //return super.onOptionsItemSelected(item);
    }

    public List<ProductModel> getShoppingProduct(Context ctx) {

        db.open();
        UserModel um = db.getthisUserData(dataProcessor.getString(PreferenceHelper.LoginEmailid));
        String products = um.getProducts();
        Log.e("TAG", "products" + products);
        ArrayList<String> productsid = new ArrayList<>(Arrays.asList(products.split(",")));
        List<ProductModel> items = new ArrayList<>();

        for (int i = 0; i < productsid.size(); i++) {
            String str = productsid.get(i).replace(",", "").trim();
            str = str.trim();
            if (str.length() > 0) {
                ProductModel pm = db.getThisProductData(Integer.parseInt(str));
                items.add(pm);
            }
        }

        db.close();

        return items;

    }

    public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.ShopView> {
        ArrayList<ProductModel> plist;
        Context context;
        TypedArray drw_arr;

        public ShopAdapter(ArrayList<ProductModel> plist, Context context) {
            this.plist = plist;
            this.context = context;
            drw_arr = context.getResources().obtainTypedArray(R.array.shop_product_image);

        }

        @NonNull
        @Override
        public ShopView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_cart_product_card, parent, false);
            ShopView vh = new ShopView(view);
            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull ShopView holder, final int position) {

            final ProductModel pm = plist.get(position);
            holder.title.setText(pm.getProductname());
            holder.image.setImageResource(drw_arr.getResourceId(pm.getPid() - 1, -1));
            holder.price.setText(pm.getProductprice());
            holder.lytParent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(context, pm.getProductname(), Toast.LENGTH_SHORT).show();
                }
            });
            holder.btnremove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    db.open();
                    UserModel um = db.getthisUserData(dataProcessor.getString(PreferenceHelper.LoginEmailid));
                    String products = um.getProducts();
                    String str = products;
                    if (products.contains(pm.getPid() + " , ")) {
                        str = products.replace(pm.getPid() + " , ", "");
                    }
                    StringBuilder sm = new StringBuilder();
                    sm.append(str);
                    db.UpdateProducts(um);
                    Toast.makeText(context, "Removed From Cart", Toast.LENGTH_SHORT).show();
                    db.close();
                    int removeIndex = position;
                    pmlist.remove(removeIndex);
                    notifyItemRemoved(removeIndex);
                }
            });
        }

        @Override
        public int getItemCount() {
            return plist.size();
        }

        public class ShopView extends RecyclerView.ViewHolder {

            @BindView(R.id.image)
            ImageView image;
            @BindView(R.id.title)
            TextView title;
            @BindView(R.id.more)
            ImageButton more;
            @BindView(R.id.price)
            TextView price;
            @BindView(R.id.lyt_parent)
            LinearLayout lytParent;
            @BindView(R.id.btnremove)
            Button btnremove;

            public ShopView(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);

            }
        }

    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
