package com.example.incesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import com.example.incesapp.helper.PreferenceHelper;
import com.example.incesapp.helper.SharedPrefHelper;

public class SplashScreen extends AppCompatActivity {

    public static SharedPreferences sp;
    public static SharedPrefHelper dataProcessor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        sp = getSharedPreferences("medical_prefs", MODE_PRIVATE);
        dataProcessor = new SharedPrefHelper(SplashScreen.this);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if(sp.contains(PreferenceHelper.LoginEmailid)) {
                    if (dataProcessor.getCondi(PreferenceHelper.Remember) && sp.contains(PreferenceHelper.LoginEmailid)) {
                        startActivity(new Intent(SplashScreen.this, CategoryList.class));
                    } else {
                        startActivity(new Intent(SplashScreen.this, MainActivity.class));
                    }
                } else {
                    startActivity(new Intent(SplashScreen.this, MainActivity.class));
                }
                finish();
            }

        }, 3000);


    }
}
