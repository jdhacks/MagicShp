package com.example.incesapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.incesapp.DatabaseHelper.Database;
import com.example.incesapp.helper.Constants;
import com.example.incesapp.helper.PreferenceHelper;
import com.example.incesapp.helper.SharedPrefHelper;
import com.example.incesapp.models.CatModel;
import com.example.incesapp.models.ProductModel;
import com.example.incesapp.models.UserModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

public class CategoryList extends AppCompatActivity {

    Database db;
    ArrayList<CatModel> pmlist = new ArrayList();

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.reccategory)
    RecyclerView reccategory;
    @BindView(R.id.btnlogout)
    Button btnlogout;

    CategoryList.ShopAdapter shpadapt;

    public static SharedPreferences sp;
    public static SharedPrefHelper dataProcessor;
    @BindView(R.id.txtcart)
    TextView txtcart;
    @BindView(R.id.btncart)
    RelativeLayout btncart;

    ArrayList<ProductModel> pmlist1 = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_list);
        ButterKnife.bind(this);
        sp = getSharedPreferences("medical_prefs", MODE_PRIVATE);
        dataProcessor = new SharedPrefHelper(CategoryList.this);
        setTitle("Magic Shop");
        setSupportActionBar(toolbar);
        db = new Database(CategoryList.this);
        db.open();
        pmlist.addAll(getCategories(CategoryList.this));

        if (!db.isExistDownProduct()) {
            pmlist1.addAll(getShoppingProduct(CategoryList.this));

            for (int i = 0; i < pmlist.size(); i++) {
                db.AddProductData(pmlist1.get(i));
            }
            UpdateCart();
        }else{
            UpdateCart();
        }

            db.close();

        LinearLayoutManager llm = new LinearLayoutManager(CategoryList.this);
        llm.setOrientation(RecyclerView.VERTICAL);
        reccategory.setLayoutManager(llm);
        reccategory.setHasFixedSize(true);
        reccategory.setNestedScrollingEnabled(false);
        shpadapt = new ShopAdapter(pmlist, CategoryList.this);
        reccategory.setAdapter(shpadapt);

        btncart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryList.this, CartList.class));
            }
        });


        btnlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LogoutDilaog();
            }
        });
    }
    public static List<ProductModel> getShoppingProduct(Context ctx) {
        List<ProductModel> items = new ArrayList<>();
        TypedArray drw_arr = ctx.getResources().obtainTypedArray(R.array.shop_product_image);
        String title_arr[] = ctx.getResources().getStringArray(R.array.shop_product_title);
        String price_arr[] = ctx.getResources().getStringArray(R.array.shop_product_price);
        String categoryarr[] = ctx.getResources().getStringArray(R.array.p_category);

        for (int i = 0; i < drw_arr.length(); i++) {
            ProductModel obj = new ProductModel();
            int j = i + 1;
            obj.setPid(j);
            obj.setPimg(drw_arr.getResourceId(i, -1));
            obj.setProductname(title_arr[i]);
            obj.setProductprice(price_arr[i]);
            obj.setProductcategory(categoryarr[i]);
            obj.setProductdescription("Provided to you by the XYZ productions");
            obj.setProductseller("Private Co. PVT LTD");
            obj.setProductrating("4.5");
            items.add(obj);
        }
        return items;
    }

    public void UpdateCart() {
        db.open();
        UserModel um = db.getthisUserData(dataProcessor.getString(PreferenceHelper.LoginEmailid));
        String products = um.getProducts();
        if (products != null) {
            if (products.length() > 0) {
                ArrayList<String> productsid = new ArrayList<>(Arrays.asList(products.split(",")));
                int pro = productsid.size() - 1;
                txtcart.setText("" + pro);
            } else {
                txtcart.setText("" + 0);
            }
        } else {
            txtcart.setText("" + 0);
        }
        db.close();

    }

    public static List<CatModel> getCategories(Context ctx) {
        List<CatModel> items = new ArrayList<>();
        TypedArray drw_arr = ctx.getResources().obtainTypedArray(R.array.shop_category_img);
        String title_arr[] = ctx.getResources().getStringArray(R.array.shop_category);

        for (int i = 0; i < drw_arr.length(); i++) {
            CatModel obj = new CatModel();
            int j = i + 1;
            obj.setCatid(j);
            obj.setCatimg(drw_arr.getResourceId(i, -1));
            obj.setCategoryName(title_arr[i]);
            items.add(obj);
        }
        return items;
    }

    public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.ShopView> {
        ArrayList<CatModel> plist;
        Context context;
        TypedArray drw_arr;

        public ShopAdapter(ArrayList<CatModel> plist, Context context) {
            this.plist = plist;
            this.context = context;
             drw_arr = context.getResources().obtainTypedArray(R.array.shop_category_img);

        }

        @NonNull
        @Override
        public ShopView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_cat_product_card, parent, false);
            ShopView vh = new ShopView(view);
            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull ShopView holder, final int position) {

            final CatModel pm = plist.get(position);


            holder.title.setText(pm.getCategoryName());
            holder.image.setImageResource(drw_arr.getResourceId(pm.getCatid() - 1, -1));
            holder.lytParent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Constants.CategoryName=plist.get(position).getCategoryName();
                    startActivity(new Intent(CategoryList.this,ShoppingList.class));
                    //Toast.makeText(context, pm.getCategoryName(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return plist.size();
        }

        public class ShopView extends RecyclerView.ViewHolder {

            @BindView(R.id.image)
            ImageView image;
            @BindView(R.id.title)
            TextView title;
            @BindView(R.id.lyt_parent)
            LinearLayout lytParent;

            public ShopView(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);

            }
        }

    }

    @Override
    public void onBackPressed() {
        ExitDialog();
    }

    private void LogoutDilaog() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(
                "Do you want to Logout???");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Logout",
                new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        sp.edit().clear().apply();
                        startActivity(new Intent(CategoryList.this, SplashScreen.class));
                        finish();
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void ExitDialog() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(
                "Do you want to Exit Application???");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Exit",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();

                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
