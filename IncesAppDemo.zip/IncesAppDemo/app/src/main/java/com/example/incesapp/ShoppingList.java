package com.example.incesapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.incesapp.DatabaseHelper.Database;
import com.example.incesapp.helper.Constants;
import com.example.incesapp.helper.PreferenceHelper;
import com.example.incesapp.helper.SharedPrefHelper;
import com.example.incesapp.models.ProductModel;
import com.example.incesapp.models.UserModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

public class ShoppingList extends AppCompatActivity {

    Database db;
    ArrayList<ProductModel> pmlist = new ArrayList();
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.recshopping)
    RecyclerView recshopping;

    ShopAdapter shpadapt;

    public static SharedPreferences sp;
    public static SharedPrefHelper dataProcessor;
    @BindView(R.id.btncart)
    RelativeLayout btncart;
    @BindView(R.id.btnlogout)
    Button btnlogout;
    @BindView(R.id.txtcart)
    TextView txtcart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);
        ButterKnife.bind(this);
        sp = getSharedPreferences("medical_prefs", MODE_PRIVATE);
        dataProcessor = new SharedPrefHelper(ShoppingList.this);
        setTitle(Constants.CategoryName);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        db = new Database(ShoppingList.this);
        db.open();/*
        if (!db.isExistDownProduct()) {
            pmlist.addAll(getShoppingProduct(ShoppingList.this));

            for (int i = 0; i < pmlist.size(); i++) {
                db.AddProductData(pmlist.get(i));
            }
        } else {*/
            pmlist.addAll(db.getAllProductDataByCat(Constants.CategoryName));
        /*}*/
        db.close();

        GridLayoutManager llm = new GridLayoutManager(ShoppingList.this, 2);
        llm.setOrientation(RecyclerView.VERTICAL);
        recshopping.setLayoutManager(llm);
        recshopping.setHasFixedSize(true);
        recshopping.setNestedScrollingEnabled(false);
        shpadapt = new ShopAdapter(pmlist, ShoppingList.this);
        recshopping.setAdapter(shpadapt);

        btncart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ShoppingList.this, CartList.class));
            }
        });


        btnlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              LogoutDilaog();
            }
        });
        UpdateCart();
     }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater();
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return false;
        //return super.onOptionsItemSelected(item);
    }

    public void UpdateCart()
    {
        db.open();
        UserModel um = db.getthisUserData(dataProcessor.getString(PreferenceHelper.LoginEmailid));
        String products = um.getProducts();
        if(products!=null) {
            if(products.length()>0) {
                ArrayList<String> productsid = new ArrayList<>(Arrays.asList(products.split(",")));
                int pro=productsid.size()-1;
                txtcart.setText("" + pro);
            }else{
                txtcart.setText(""+0);
            }
        }else{
            txtcart.setText(""+0);
        }
        db.close();

    }
    public static List<ProductModel> getShoppingProduct(Context ctx) {
        List<ProductModel> items = new ArrayList<>();
        TypedArray drw_arr = ctx.getResources().obtainTypedArray(R.array.shop_product_image);
        String title_arr[] = ctx.getResources().getStringArray(R.array.shop_product_title);
        String price_arr[] = ctx.getResources().getStringArray(R.array.shop_product_price);
        String categoryarr[] = ctx.getResources().getStringArray(R.array.p_category);

        for (int i = 0; i < drw_arr.length(); i++) {
            ProductModel obj = new ProductModel();
            int j = i + 1;
            obj.setPid(j);
            obj.setPimg(drw_arr.getResourceId(i, -1));
            obj.setProductname(title_arr[i]);
            obj.setProductprice(price_arr[i]);
            obj.setProductcategory(categoryarr[i]);
            obj.setProductdescription("Provided to you by the XYZ productions");
            obj.setProductseller("Private Co. PVT LTD");
            obj.setProductrating("4.5");
            items.add(obj);
        }
        return items;
    }

    public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.ShopView> {
        ArrayList<ProductModel> plist;
        Context context;
        TypedArray drw_arr;
        public ShopAdapter(ArrayList<ProductModel> plist, Context context) {
            this.plist = plist;
            this.context = context;
            drw_arr = context.getResources().obtainTypedArray(R.array.shop_product_image);

        }

        @NonNull
        @Override
        public ShopView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_shop_product_card, parent, false);
            ShopView vh = new ShopView(view);
            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull ShopView holder, int position) {

            final ProductModel pm = plist.get(position);


            holder.title.setText(pm.getProductname());
            holder.image.setImageResource(drw_arr.getResourceId(pm.getPid()-1, -1));
            holder.price.setText(pm.getProductprice());
            holder.lytParent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(context, pm.getProductname(), Toast.LENGTH_SHORT).show();
                }
            });
            holder.btnadd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    db.open();
                    UserModel um = db.getthisUserData(dataProcessor.getString(PreferenceHelper.LoginEmailid));
                    String products = um.getProducts();
                    if(products!=null) {
                        if (products.length() > 0) {

                            if (products.contains(pm.getPid() + " , ")) {
                                Toast.makeText(context, "Already Added", Toast.LENGTH_SHORT).show();
                            }else{
                                StringBuilder sm = new StringBuilder();
                                sm.append(products);
                                sm.append(pm.getPid());
                                sm.append(" , ");
                                um.setProducts(sm.toString());
                                db.UpdateProducts(um);
                                Toast.makeText(context, "Added To Cart", Toast.LENGTH_SHORT).show();
                                UpdateCart();

                            }
                        }else{
                            StringBuilder sm = new StringBuilder();
                            sm.append(products);
                            sm.append(pm.getPid());
                            sm.append(" , ");
                            um.setProducts(sm.toString());
                            db.UpdateProducts(um);
                            Toast.makeText(context, "Added To Cart", Toast.LENGTH_SHORT).show();
                            UpdateCart();

                        }
                    }else {

/*
                    String products= db.getUserProducts(dataProcessor.getString(PreferenceHelper.LoginEmailid));
*/
                        StringBuilder sm = new StringBuilder();
                        sm.append(products);
                        sm.append(pm.getPid());
                        sm.append(" , ");
                        um.setProducts(sm.toString());
                        db.UpdateProducts(um);
                        Toast.makeText(context, "Added To Cart", Toast.LENGTH_SHORT).show();
                        UpdateCart();
                    }
                    db.close();
                }
            });
        }

        @Override
        public int getItemCount() {
            return plist.size();
        }

        public class ShopView extends RecyclerView.ViewHolder {

            @BindView(R.id.image)
            ImageView image;
            @BindView(R.id.title)
            TextView title;
            @BindView(R.id.more)
            ImageButton more;
            @BindView(R.id.price)
            TextView price;
            @BindView(R.id.lyt_parent)
            LinearLayout lytParent;
            @BindView(R.id.btnadd)
            Button btnadd;

            public ShopView(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);

            }
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        UpdateCart();
    }

    @Override
    public void onBackPressed() {
       finish();
    }

    private void LogoutDilaog() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(
                "Do you want to Logout???");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Logout",
                new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        sp.edit().clear().apply();
                        startActivity(new Intent(ShoppingList.this,SplashScreen.class));
                        finish();
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void ExitDialog() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(
                "Do you want to Exit Application???");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Exit",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();

                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
