package com.example.incesapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.balysv.materialripple.MaterialRippleLayout;
import com.example.incesapp.DatabaseHelper.Database;
import com.example.incesapp.helper.PreferenceHelper;
import com.example.incesapp.helper.SharedPrefHelper;
import com.example.incesapp.models.UserModel;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    Database db;
    public static SharedPreferences sp;
    public static SharedPrefHelper dataProcessor;
    @BindView(R.id.edtemailid)
    TextInputEditText edtemailid;
    @BindView(R.id.edtpass)
    TextInputEditText edtpass;
    @BindView(R.id.forgot_password)
    TextView forgotPassword;
    @BindView(R.id.btnsignin)
    MaterialRippleLayout btnsignin;
    @BindView(R.id.btnsignup)
    MaterialRippleLayout btnsignup;
    @BindView(R.id.signincheeck)
    AppCompatCheckBox signincheeck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        db = new Database(MainActivity.this);

        checkAndRequestPermissions();
        sp = getSharedPreferences("medical_prefs", MODE_PRIVATE);
        dataProcessor = new SharedPrefHelper(MainActivity.this);
        db.open();
        if (!db.isExistDownUser()) {

            UserModel p = new UserModel();
            p.setName("Mr. abc");
            p.setEmailid("abc@gmail.com");
            p.setAddress("Milson Street , CA");
            p.setMobilenumber("+911212121212");
            p.setBirthdate("03/01/1995");
            p.setProducts("");
            p.setPassword("abc@people");
            db.AddUserData(p);
        }
        db.close();

        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SignUpActivity.class));

            }
        });

        btnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edtemailid.getText().toString().trim().equals("")) {
                    Toast.makeText(MainActivity.this, "Please Enter Valid Email Id", Toast.LENGTH_LONG).show();
                } else if (edtpass.getText().toString().trim().equals("")) {
                    Toast.makeText(MainActivity.this, "Please Enter Valid Password", Toast.LENGTH_LONG).show();
                } else {
                    db.open();
                    if (db.getUserLogin(edtemailid.getText().toString().trim(), edtpass.getText().toString().trim())) {
                        dataProcessor.setString(PreferenceHelper.LOGINTYPE, PreferenceHelper.TYPEPEOPLE);
                        dataProcessor.setString(PreferenceHelper.LoginEmailid, edtemailid.getText().toString().trim());
                        dataProcessor.setCondi(PreferenceHelper.Remember, signincheeck.isChecked());

                        startActivity(new Intent(MainActivity.this, CategoryList.class));
                    } else {
                        if (db.getUserExits(edtemailid.getText().toString().trim())) {
                            Toast.makeText(MainActivity.this, "Wrong Email Id or Password", Toast.LENGTH_LONG).show();

                        } else {
                            Toast.makeText(MainActivity.this, "No Email ID Found", Toast.LENGTH_LONG).show();
                        }
                    }

                    db.close();
                }
            }
        });

    }

    private boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE");
        int locationPermission = ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE");

        List<String> listPermissionsNeeded = new ArrayList();
        if (locationPermission != 0) {
            listPermissionsNeeded.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (permissionSendMessage != 0) {
            listPermissionsNeeded.add("android.permission.READ_EXTERNAL_STORAGE");
        }

        if (listPermissionsNeeded.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
        return false;
    }
}
