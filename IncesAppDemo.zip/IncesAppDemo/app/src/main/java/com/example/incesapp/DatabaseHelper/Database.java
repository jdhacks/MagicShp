package com.example.incesapp.DatabaseHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

import com.example.incesapp.models.ProductModel;
import com.example.incesapp.models.UserModel;

import java.io.File;
import java.util.ArrayList;



public class Database extends SQLiteOpenHelper {
    SQLiteDatabase db;


    public final static String DB_NAME = "onlineshop" + ".db";
    public final static int DB_VERSION = 1;

    public static final String USER_TBl = "user_table";

    public String USER_ID = "uid";
    public String USER_NAME = "name";
    public String USER_UNAME = "username";
    public String USER_MOBILENUMBER = "u_mobile";
    public String USER_EMAILID = "u_emailid";
    public String USER_BIRTHDATE = "u_birthdate";
    public String USER_ADDRESS = "uaddress";
    public String USER_PRODUCTS = "uproducts";
    public String USER_PASSWORD = "u_password";


    //CREATE QUERY
    public String CREATE_USER = "Create table " + USER_TBl + "(" + USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + USER_NAME + " TEXT,"
            + USER_UNAME + " TEXT,"
            + USER_MOBILENUMBER + " TEXT,"
            + USER_EMAILID + " TEXT,"
            + USER_BIRTHDATE + " TEXT,"
            + USER_ADDRESS + " TEXT,"
            + USER_PRODUCTS + " TEXT,"
            + USER_PASSWORD + " TEXT)";


    public static final String PRODUCT_TBl = "product_table";

    public String PRODUCT_ID = "pid";
    public String PRODUCT_NAME = "pname";
    public String PRODUCT_IMAGE = "pimg";
    public String PRODUCT_DESC = "pdescription";
    public String PRODUCT_CATEGORY = "p_category";
    public String PRODUCT_PRICE = "p_price";
    public String PRODUCT_RATING = "p_rating";
    public String PRODUCT_REVIEW = "p_review";
    public String PRODUCT_REVIEWBY = "reviewby";
    public String PRODUCT_SELLER = "p_seller";

    //CREATE QUERY
    public String CREATE_PRODUCT = "Create table " + PRODUCT_TBl + "(" + PRODUCT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + PRODUCT_NAME + " TEXT,"
            + PRODUCT_IMAGE + " INTEGER,"
            + PRODUCT_DESC + " TEXT,"
            + PRODUCT_CATEGORY + " TEXT,"
            + PRODUCT_PRICE + " TEXT,"
            + PRODUCT_RATING + " TEXT,"
            + PRODUCT_REVIEW + " TEXT,"
            + PRODUCT_REVIEWBY + " TEXT,"
            + PRODUCT_SELLER + " TEXT)";


     public Database(Context context) {
         super(context, DB_NAME , null, DB_VERSION);
         //super(context, Environment.getExternalStorageDirectory() + File.separator + DB_NAME, null, DB_VERSION);
     }
/*
    public Database(Context context) {//Environment.getExternalStorageDirectory() + File.separator +"Medical/"
        super(context, Environment.getExternalStorageDirectory() + File.separator + DB_NAME,null, DB_VERSION);
    }
*/


    //GET WRITABLE
    public void open() {
       /* String DBPath = Environment.getExternalStorageDirectory() + File.separator +DB_NAME;
          File file = new File(DBPath);
          Log.e("TAG","database"+file.exists());
        if (file.exists() && !file.isDirectory())
        {

            file.setReadable(true);
            file.setWritable(true);
            db = SQLiteDatabase.openDatabase(DBPath,null, SQLiteDatabase.OPEN_READWRITE);

        }
*/

        db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER);
        db.execSQL(CREATE_PRODUCT);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void AddUserData(UserModel fav) {

        ContentValues cv = new ContentValues();

        cv.put(USER_NAME, fav.getName());
        cv.put(USER_UNAME, fav.getUsername());
        cv.put(USER_MOBILENUMBER, fav.getMobilenumber());
        cv.put(USER_EMAILID, fav.getEmailid());
        cv.put(USER_BIRTHDATE, fav.getBirthdate());
        cv.put(USER_ADDRESS, fav.getAddress());
        cv.put(USER_PRODUCTS, fav.getProducts());
        cv.put(USER_PASSWORD, fav.getPassword());

        db.insert(USER_TBl, null, cv);

    }


    public void UpdateProducts(UserModel fav)
    {
        ContentValues cv = new ContentValues();
        cv.put(USER_PRODUCTS, fav.getProducts());
        db.update(USER_TBl, cv, USER_ID+"="+fav.getUserid(), null);
    }
    public ArrayList<UserModel> getAllUserData() {

        String quer = "select * from " + USER_TBl;

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<UserModel> all_data = new ArrayList<UserModel>();
        UserModel sp;

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

            sp = new UserModel();
            sp.setUserid(cursor.getInt(cursor.getColumnIndex(USER_ID)));
            sp.setName(cursor.getString(cursor.getColumnIndex(USER_NAME)));
            sp.setUsername(cursor.getString(cursor.getColumnIndex(USER_UNAME)));
            sp.setBirthdate(cursor.getString(cursor.getColumnIndex(USER_BIRTHDATE)));
            sp.setEmailid(cursor.getString(cursor.getColumnIndex(USER_EMAILID)));
            sp.setMobilenumber(cursor.getString(cursor.getColumnIndex(USER_MOBILENUMBER)));
            sp.setAddress(cursor.getString(cursor.getColumnIndex(USER_ADDRESS)));
            sp.setProducts(cursor.getString(cursor.getColumnIndex(USER_PRODUCTS)));
            sp.setPassword(cursor.getString(cursor.getColumnIndex(USER_PASSWORD)));

            all_data.add(sp);
        }
        cursor.close();
        return all_data;
    }

    public UserModel getthisUserData(String emailid) {

        Log.e("TAG","uname"+emailid);
        String quer = "select * from " + USER_TBl+" WHERE  "+USER_EMAILID+" ='"+emailid +"'";

        Cursor cursor = db.rawQuery(quer, null);

        UserModel sp=null;
Log.e("TAG","Count"+cursor.getCount());

        if (cursor.getCount()>0) {
           cursor.moveToFirst();
            sp = new UserModel();
            sp.setUserid(cursor.getInt(cursor.getColumnIndex(USER_ID)));
            sp.setName(cursor.getString(cursor.getColumnIndex(USER_NAME)));
            sp.setUsername(cursor.getString(cursor.getColumnIndex(USER_UNAME)));
            sp.setBirthdate(cursor.getString(cursor.getColumnIndex(USER_BIRTHDATE)));
            sp.setEmailid(cursor.getString(cursor.getColumnIndex(USER_EMAILID)));
            sp.setMobilenumber(cursor.getString(cursor.getColumnIndex(USER_MOBILENUMBER)));
            sp.setAddress(cursor.getString(cursor.getColumnIndex(USER_ADDRESS)));
            sp.setProducts(cursor.getString(cursor.getColumnIndex(USER_PRODUCTS)));
            sp.setPassword(cursor.getString(cursor.getColumnIndex(USER_PASSWORD)));


        }
        cursor.close();
        return sp;
    }


    public String getUserProducts(String emailid) {

        Log.e("TAG","uname"+emailid);
        String quer = "select * from " + USER_TBl+" WHERE  "+USER_EMAILID+" ='"+emailid +"'";

        Cursor cursor = db.rawQuery(quer, null);

        UserModel sp=null;
        Log.e("TAG","Count"+cursor.getCount());
        String pro=null;
        if (cursor.getCount()>0) {
            cursor.moveToFirst();
            pro=cursor.getString(cursor.getColumnIndex(USER_PRODUCTS));

        }
        return pro;
    }
    public void DeleteDataUser(String name, int id) {

        db.delete(USER_TBl, USER_ID + " =" + id + " AND " + USER_NAME + "='" + name + "'", null);

    }

    public boolean validRecordUser(String name, int Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String q = "select * from " + USER_TBl + " where " + USER_NAME + " = '" + name + "'";
        Log.d("TAG", "is valid record arguments" + name + "...." + Dir);
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            Integer exid = cursor.getInt(cursor.getColumnIndex(USER_ID));
            String dir = cursor.getString(cursor.getColumnIndex(USER_NAME));
            Log.d("TAG", "Database data..." + exid + "...." + dir + "...is valid record arguments" + name + "...." + Dir);

            if (exid==Dir && dir.equalsIgnoreCase(dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name" + name);

                cursor.close();
                return true;
            } else {
                return false;
            }
        }
        cursor.close();
        return false;
    }

    public boolean isDownUser(String name, int id) {
        db = getReadableDatabase();
        Cursor cursor;
        String q = "select * from " + USER_TBl + " where " + USER_NAME + " = " + name + "";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            int exid = cursor.getInt(cursor.getColumnIndex(USER_ID));
            String dir = cursor.getString(cursor.getColumnIndex(USER_NAME));
            if (exid==id && dir.equalsIgnoreCase(name)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name" + name);

                cursor.close();
                return true;
            } else {
                return false;
            }
        }
        cursor.close();
        return false;
    }

    /*public String getPathUser(String id, String Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String path = null;
        String q = "select * from " + USER_TBl + " where " + USER_NAME + " = '" + id + "'";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            String exid = cursor.getString(cursor.getColumnIndex(USER_ID));
            String dir = cursor.getString(cursor.getColumnIndex(USER_NAME));
            if (exid.equalsIgnoreCase(id) && dir.equalsIgnoreCase(Dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name " + Dir);
                path = cursor.getString(cursor.getColumnIndex(DOWN_AUDIOLINK));
                cursor.close();
                return path;
            } else {
                return path;
            }
        }
        cursor.close();
        return path;
    }
*/
    public boolean isExistDownUser() {
        String query = "select * from " + USER_TBl;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }
    public boolean getUserExits(String emailid) {
        String query = "select * from " + USER_TBl+" WHERE  "+USER_EMAILID+" ='"+emailid +"'";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }
    public boolean getUserLogin(String emailid, String password) {
        String query = "select * from " + USER_TBl+" WHERE  "+USER_EMAILID+" ='"+emailid +"' AND "+USER_PASSWORD+" ='"+password+"'";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }


    /*------------------------------------------------------------------*/

    public void AddProductData(ProductModel fav) {

        ContentValues cv = new ContentValues();

        cv.put(PRODUCT_NAME, fav.getProductname());
        cv.put(PRODUCT_CATEGORY, fav.getProductcategory());
        cv.put(PRODUCT_DESC, fav.getProductdescription());
        cv.put(PRODUCT_PRICE, fav.getProductprice());
        cv.put(PRODUCT_RATING, fav.getProductrating());
        cv.put(PRODUCT_REVIEW, fav.getProductreview());
        cv.put(PRODUCT_REVIEWBY, fav.getReviewby());
        cv.put(PRODUCT_SELLER, fav.getProductseller());

        db.insert(PRODUCT_TBl, null, cv);

    }

    public boolean getProductExits(String emailid) {
        String query = "select * from " + PRODUCT_TBl+" WHERE  "+PRODUCT_NAME+" ='"+emailid +"'";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }
    public ArrayList<ProductModel> getAllProductDataByCat(String cat) {

        String quer = "select * from " + PRODUCT_TBl+" WHERE  "+PRODUCT_CATEGORY+" ='"+cat +"'";

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<ProductModel> all_data = new ArrayList<ProductModel>();
        ProductModel sp;

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

            sp = new ProductModel();
            sp.setPid(cursor.getInt(cursor.getColumnIndex(PRODUCT_ID)));
            sp.setProductname(cursor.getString(cursor.getColumnIndex(PRODUCT_NAME)));
            sp.setProductcategory(cursor.getString(cursor.getColumnIndex(PRODUCT_CATEGORY)));
            sp.setProductdescription(cursor.getString(cursor.getColumnIndex(PRODUCT_DESC)));
            sp.setProductprice(cursor.getString(cursor.getColumnIndex(PRODUCT_PRICE)));
            sp.setProductrating(cursor.getString(cursor.getColumnIndex(PRODUCT_RATING)));
            sp.setProductreview(cursor.getString(cursor.getColumnIndex(PRODUCT_REVIEW)));
            sp.setReviewby(cursor.getInt(cursor.getColumnIndex(PRODUCT_REVIEWBY)));
            sp.setProductseller(cursor.getString(cursor.getColumnIndex(PRODUCT_SELLER)));

            all_data.add(sp);
        }
        return all_data;
    }

    public ArrayList<ProductModel> getAllProductData() {

        String quer = "select * from " + PRODUCT_TBl;

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<ProductModel> all_data = new ArrayList<ProductModel>();
        ProductModel sp;

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

            sp = new ProductModel();
            sp.setPid(cursor.getInt(cursor.getColumnIndex(PRODUCT_ID)));
            sp.setProductname(cursor.getString(cursor.getColumnIndex(PRODUCT_NAME)));
            sp.setProductcategory(cursor.getString(cursor.getColumnIndex(PRODUCT_CATEGORY)));
            sp.setProductdescription(cursor.getString(cursor.getColumnIndex(PRODUCT_DESC)));
            sp.setProductprice(cursor.getString(cursor.getColumnIndex(PRODUCT_PRICE)));
            sp.setProductrating(cursor.getString(cursor.getColumnIndex(PRODUCT_RATING)));
            sp.setProductreview(cursor.getString(cursor.getColumnIndex(PRODUCT_REVIEW)));
            sp.setReviewby(cursor.getInt(cursor.getColumnIndex(PRODUCT_REVIEWBY)));
            sp.setProductseller(cursor.getString(cursor.getColumnIndex(PRODUCT_SELLER)));

            all_data.add(sp);
        }
        return all_data;
    }

    public ProductModel getThisProductData(int id) {

        String quer = "select * from " + PRODUCT_TBl+" WHERE  "+PRODUCT_ID+" ="+id +"";

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<ProductModel> all_data = new ArrayList<ProductModel>();
        ProductModel sp = null;

        if(cursor.getCount()>0) {
          cursor.moveToFirst();
            sp = new ProductModel();
            sp.setPid(cursor.getInt(cursor.getColumnIndex(PRODUCT_ID)));
            sp.setProductname(cursor.getString(cursor.getColumnIndex(PRODUCT_NAME)));
            sp.setProductcategory(cursor.getString(cursor.getColumnIndex(PRODUCT_CATEGORY)));
            sp.setProductdescription(cursor.getString(cursor.getColumnIndex(PRODUCT_DESC)));
            sp.setProductprice(cursor.getString(cursor.getColumnIndex(PRODUCT_PRICE)));
            sp.setProductrating(cursor.getString(cursor.getColumnIndex(PRODUCT_RATING)));
            sp.setProductreview(cursor.getString(cursor.getColumnIndex(PRODUCT_REVIEW)));
            sp.setReviewby(cursor.getInt(cursor.getColumnIndex(PRODUCT_REVIEWBY)));
            sp.setProductseller(cursor.getString(cursor.getColumnIndex(PRODUCT_SELLER)));

            // all_data.add(sp);
        }
        return sp;
    }

    public void DeleteDataProduct(String name, int id) {

        db.delete(PRODUCT_TBl, PRODUCT_ID + " =" + id + " AND " + PRODUCT_NAME + "='" + name + "'", null);

    }

    public boolean validRecordProduct(String name, int Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String q = "select * from " + PRODUCT_TBl + " where " + PRODUCT_NAME + " = '" + name + "'";
        Log.d("TAG", "is valid record arguments" + name + "...." + Dir);
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            Integer exid = cursor.getInt(cursor.getColumnIndex(PRODUCT_ID));
            String dir = cursor.getString(cursor.getColumnIndex(PRODUCT_NAME));
            Log.d("TAG", "Database data..." + exid + "...." + dir + "...is valid record arguments" + name + "...." + Dir);

            if (exid==Dir && dir.equalsIgnoreCase(dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name" + name);

                cursor.close();
                return true;
            } else {
                return false;
            }
        }
        cursor.close();
        return false;
    }

    public boolean isDownProduct(String name, int id) {
        db = getReadableDatabase();
        Cursor cursor;
        String q = "select * from " + PRODUCT_TBl + " where " + PRODUCT_NAME + " = " + name + "";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            int exid = cursor.getInt(cursor.getColumnIndex(PRODUCT_ID));
            String dir = cursor.getString(cursor.getColumnIndex(PRODUCT_NAME));
            if (exid==id && dir.equalsIgnoreCase(name)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name" + name);

                cursor.close();
                return true;
            } else {
                return false;
            }
        }
        cursor.close();
        return false;
    }

    /*public String getPath(String id, String Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String path = null;
        String q = "select * from " + PRODUCT_TBl + " where " + PRODUCT_NAME + " = '" + id + "'";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            String exid = cursor.getString(cursor.getColumnIndex(USER_ID));
            String dir = cursor.getString(cursor.getColumnIndex(USER_NAME));
            if (exid.equalsIgnoreCase(id) && dir.equalsIgnoreCase(Dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name " + Dir);
                path = cursor.getString(cursor.getColumnIndex(DOWN_AUDIOLINK));
                cursor.close();
                return path;
            } else {
                return path;
            }
        }
        cursor.close();
        return path;
    }
*/
    public boolean isExistDownProduct() {
        String query = "select * from " + PRODUCT_TBl;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }

    /*------------------------------------------------------------------*/

/*
    public void AddReviewData(ReviewModel fav) {

        ContentValues cv = new ContentValues();

        cv.put(Review_date, fav.getReview_date());
        cv.put(Review_ans, fav.getReview_ans());
        cv.put(Review_que, fav.getReview_que());
        cv.put(Review_ansid, fav.getReview_ansid());
        cv.put(Review_quid, fav.getReview_quid());
        cv.put(Review_bid, fav.getReview_bid());
        cv.put(Review_sub, fav.getReview_sub());
        cv.put(Review_rev, fav.getReview_rev());
        db.insert(Review_TBl, null, cv);

    }

    public ArrayList<ReviewModel> getAllReviewData() {

        String quer = "select * from " + Review_TBl;

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<ReviewModel> all_data = new ArrayList<ReviewModel>();
        ReviewModel sp;

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

            sp = new ReviewModel();
            sp.setReview_ID(cursor.getInt(cursor.getColumnIndex(Review_ID)));
            sp.setReview_ans(cursor.getString(cursor.getColumnIndex(Review_ans)));
            sp.setReview_date(cursor.getString(cursor.getColumnIndex(Review_date)));
            sp.setReview_que(cursor.getString(cursor.getColumnIndex(Review_que)));
            sp.setReview_ansid(cursor.getString(cursor.getColumnIndex(Review_ansid)));
            sp.setReview_sub(cursor.getString(cursor.getColumnIndex(Review_sub)));
            sp.setReview_rev(cursor.getString(cursor.getColumnIndex(Review_rev)));
            sp.setReview_quid(cursor.getString(cursor.getColumnIndex(Review_quid)));
            sp.setReview_bid(cursor.getString(cursor.getColumnIndex(Review_bid)));

            all_data.add(sp);
        }
        return all_data;
    }

    public void DeleteDataReview(String name, int id) {

        db.delete(Review_TBl, Review_ID + " =" + id , null);

    }

    */
/*public String getPath(String id, String Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String path = null;
        String q = "select * from " + PRODUCT_TBl + " where " + PRODUCT_NAME + " = '" + id + "'";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            String exid = cursor.getString(cursor.getColumnIndex(USER_ID));
            String dir = cursor.getString(cursor.getColumnIndex(USER_NAME));
            if (exid.equalsIgnoreCase(id) && dir.equalsIgnoreCase(Dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name " + Dir);
                path = cursor.getString(cursor.getColumnIndex(DOWN_AUDIOLINK));
                cursor.close();
                return path;
            } else {
                return path;
            }
        }
        cursor.close();
        return path;
    }
*//*

    public boolean isExistDownReview() {
        String query = "select * from " + Review_TBl;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }
*/

}