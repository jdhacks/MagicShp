package com.example.incesapp.models;

public class ProductModel {
    int id;
    int pid;

    public int getPimg() {
        return pimg;
    }

    public void setPimg(int pimg) {
        this.pimg = pimg;
    }

    int pimg;
    String productname;
    String productdescription;
    String productcategory;
    String productprice;
    String productrating;
    String productreview;

    public String getProductseller() {
        return productseller;
    }

    public void setProductseller(String productseller) {
        this.productseller = productseller;
    }

    String productseller;
    int reviewby;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getProductdescription() {
        return productdescription;
    }

    public void setProductdescription(String productdescription) {
        this.productdescription = productdescription;
    }

    public String getProductcategory() {
        return productcategory;
    }

    public void setProductcategory(String productcategory) {
        this.productcategory = productcategory;
    }

    public String getProductprice() {
        return productprice;
    }

    public void setProductprice(String productprice) {
        this.productprice = productprice;
    }

    public String getProductrating() {
        return productrating;
    }

    public void setProductrating(String productrating) {
        this.productrating = productrating;
    }

    public String getProductreview() {
        return productreview;
    }

    public void setProductreview(String productreview) {
        this.productreview = productreview;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public int getReviewby() {
        return reviewby;
    }

    public void setReviewby(int reviewby) {
        this.reviewby = reviewby;
    }
}
