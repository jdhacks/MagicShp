package com.example.incesapp.helper;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class PreferenceHelper {
    public static final String LOGINTYPE="logintype";
    public static final String TYPEDOC="doctor";
    public static final String TYPEPEOPLE="people";
    public static final String LoginEmailid="emaillogin";
    public static final String Remember="remember_me";


    public static final String[] questionSubjects={"Select Subject","Awareness","Healing Disease","Precautins","Preventions"};

    public static int getAge (int _year, int _month, int _day) {

        GregorianCalendar cal = new GregorianCalendar();
        int y, m, d, a;

        y = cal.get(Calendar.YEAR);
        m = cal.get(Calendar.MONTH);
        d = cal.get(Calendar.DAY_OF_MONTH);
        cal.set(_year, _month, _day);
        a = y - cal.get(Calendar.YEAR);
        if ((m < cal.get(Calendar.MONTH))
                || ((m == cal.get(Calendar.MONTH)) && (d < cal
                .get(Calendar.DAY_OF_MONTH)))) {
            --a;
        }
        if(a < 0)
            throw new IllegalArgumentException("Age < 0");
        return a;
    }

}
