package com.example.incesapp.helper;

public class Constants {
    public static String CategoryName;
}
